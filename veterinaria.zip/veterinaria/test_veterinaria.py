import unittest
import os
import json
import csv
from veterinaria import Dueno, Mascota, Consulta, export_to_csv, import_from_csv, export_to_json, import_from_json, mascotas, duenos

class TestVeterinaria(unittest.TestCase):

    def setUp(self):
        self.dueno = Dueno("Carlos Pérez", "123456789", "Calle 123")
        self.mascota = Mascota("Max", "Perro", "Labrador", 5, self.dueno)
        self.consulta = Consulta("10/05/2025", "Vacunación", "Vacuna aplicada", self.mascota)
        self.mascota.agregar_consulta(self.consulta)

        duenos.clear()
        mascotas.clear()
        duenos.append(self.dueno)
        mascotas.append(self.mascota)

    def tearDown(self):
        if os.path.exists("mascotas_dueños.csv"):
            os.remove("mascotas_dueños.csv")
        if os.path.exists("consultas.json"):
            os.remove("consultas.json")

    def test_creacion_objetos(self):
        self.assertEqual(self.dueno.nombre, "Carlos Pérez")
        self.assertEqual(self.mascota.nombre, "Max")
        self.assertEqual(self.consulta.motivo, "Vacunación")

    def test_agregar_consulta(self):
        self.assertEqual(len(self.mascota.consultas), 1)
        self.assertEqual(self.mascota.consultas[0].diagnostico, "Vacuna aplicada")

    def test_edad_negativa_mascota(self):
        with self.assertRaises(ValueError):
            Mascota("Luna", "Gato", "Persa", -2, self.dueno)

    def test_export_import_csv(self):
        export_to_csv()
        self.assertTrue(os.path.exists("mascotas_dueños.csv"))

        # Limpiar listas y volver a importar
        mascotas.clear()
        duenos.clear()
        import_from_csv()
        self.assertGreater(len(mascotas), 0)
        self.assertEqual(mascotas[0].nombre, "Max")

    def test_export_import_json(self):
        export_to_json()
        self.assertTrue(os.path.exists("consultas.json"))

        mascotas[0].consultas.clear()
        import_from_json()
        self.assertGreater(len(mascotas[0].consultas), 0)
        self.assertEqual(mascotas[0].consultas[0].motivo, "Vacunación")

if __name__ == '__main__':
    unittest.main()
